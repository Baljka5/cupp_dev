from django.apps import AppConfig


class ZipmanagerConfig(AppConfig):
    name = 'cupp.zipmanager'
